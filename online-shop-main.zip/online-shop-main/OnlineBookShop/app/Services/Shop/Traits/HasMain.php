<?PhP 
namespace App\Services\shop\Traits;

trait HasMain{

}
