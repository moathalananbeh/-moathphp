<?PhP 
namespace App\Support\Notification\Providers\Contracts;

/* Implement interface to organize notification */
interface ProviderInterface{
    public function send();
}

