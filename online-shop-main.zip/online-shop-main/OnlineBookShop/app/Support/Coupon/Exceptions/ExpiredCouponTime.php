<?php

namespace App\Support\Coupon\Exceptions;

use Exception;

class ExpiredCouponTime extends Exception{
    
}
