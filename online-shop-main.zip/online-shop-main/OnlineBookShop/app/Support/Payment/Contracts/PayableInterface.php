<?PhP 
namespace App\Support\Payment\Contracts;

interface PayableInterface{
    public function pay();
}

