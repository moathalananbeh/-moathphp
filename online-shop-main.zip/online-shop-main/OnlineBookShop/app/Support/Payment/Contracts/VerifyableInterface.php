<?PhP 
namespace App\Support\Payment\Contracts;

interface VerifyableInterface{
    public function verify();
}

