<?PhP 
namespace App\Support\Payment\Exception;

class GatewayNotFoundException extends \Exception{
}

