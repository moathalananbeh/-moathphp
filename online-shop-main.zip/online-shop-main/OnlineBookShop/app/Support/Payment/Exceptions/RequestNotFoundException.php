<?php

namespace App\Support\Payment\Exceptions;

use Exception;

class RequestNotFoundException extends Exception{
}
