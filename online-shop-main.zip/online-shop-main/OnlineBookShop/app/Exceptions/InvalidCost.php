<?php

namespace App\Exceptions;

use Exception;

class InvalidCost extends Exception{
}
