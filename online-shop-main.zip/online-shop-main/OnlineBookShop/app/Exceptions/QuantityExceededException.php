<?php

namespace App\Exceptions;

use Exception;

class QuantityExceededException extends Exception
{
    //
}
