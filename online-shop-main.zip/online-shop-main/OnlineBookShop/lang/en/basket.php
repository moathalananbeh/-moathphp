<?PhP 

return [
    'empty basket' => 'Basket is empty! Make your purchase =>go to the <a href=":link" style="color: #ff5c00; text-decoration: none;">
    PRODUCTS PAGE</a>'
];