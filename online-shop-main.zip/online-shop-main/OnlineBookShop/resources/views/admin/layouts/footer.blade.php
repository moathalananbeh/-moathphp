<script src="/admin/js/vendor/jquery-2.2.4.min.js"></script>
<script src="/admin/js/metisMenu.min.js"></script>
<script src="/admin/js/plugins.js"></script>
<script src="/admin/js/scripts.js"></script>
</body>
</html>