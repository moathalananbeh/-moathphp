<?PhP 

return[
    'images_products_url' => 'http://localhost/images/products/'
];